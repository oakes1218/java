package Grade;

import java.io.IOException;

public class Search {
	public static void main (String[] agre) throws IOException{
		Studen studen = new Studen();
		//Readfile rf = new Readfile();
		studen.data();
		//rf.Read();
	}
}
