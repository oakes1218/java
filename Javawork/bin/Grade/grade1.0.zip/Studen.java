package Grade;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;


public class Studen {
	
	private HashMap<String, Integer> map = new HashMap<String, Integer> ();
	
	public void data(){
		
		Readfile rf = new Readfile();
		
	
		ArrayList<Map.Entry<String, Integer>> list_Data = new ArrayList<Map.Entry<String,Integer>>(map.entrySet());
		Collections.sort(list_Data,new Comparator<Map.Entry<String, Integer>>() {
	        @Override
	        public int compare(Map.Entry<String, Integer> entry1, Map.Entry<String, Integer> entry2) {
	            return (entry2.getValue()-entry1.getValue());
	        }
		});  
	
		//System.out.println(list_Data.get(1));
			for(int i = 0; i < list_Data.size()*0.25 ; i++){
				System.out.println(list_Data.get(i)+" - " + "優");
			}
		
			for(int i = (int) (list_Data.size()*0.25)+1 ; i < list_Data.size()*0.25*2 ; i++){
				System.out.println(list_Data.get(i)+" - " + "良");
			}
			
			for(int i = (int) (list_Data.size()*0.25)*2+1 ; i < list_Data.size()*0.25*3-1 ; i++){
				System.out.println(list_Data.get(i)+" - " + "中");
			}
			
			for(int i = (int) (list_Data.size()*0.25)*3+1 ; i < list_Data.size()*0.25*4 ; i++){
				System.out.println(list_Data.get(i)+" - " + "差");
			}
		
		}

}
