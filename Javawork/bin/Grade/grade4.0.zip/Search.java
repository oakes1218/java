package Grade;

import java.io.IOException;

public class Search {
	public static void main (String[] agre) throws IOException{
		Studen studen = new Studen();
		//Readfile readfile = new Readfile();
		//readfile.Read();
		studen.data();
		
	}
}
