package Park;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Parking {
	
	int hour = 0;
	int minute = 0;
	int money = 0;
	String begin ;
	String end ;
	int total_minute = 0;
	StringBuffer sb = new StringBuffer();
	
	public  void diffTime() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("請輸入停車入場時間(24小時制) yyyy-MM-dd-HH:mm:ss");
		begin = scanner.next();
		end = scanner.next(); 
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss");
		
		try {  
        java.util.Date starDate = sdf.parse(begin);
        java.util.Date endDate = sdf.parse(end);
        
        total_minute = (int) ((endDate.getTime() - starDate.getTime())/(1000*60));  
        
        hour = (int) total_minute/60;  
        minute = (int) total_minute%60; 
        
        sb.append("總共停：").append(hour).append("小時又").append(minute).append("分鐘");  
       
		 } catch (ParseException e) {  
		        System.out.println("輸入格式錯誤");  
		    } 
        
        if(hour < 4){
        	money = hour * 20;
        	if(minute > 0){
        		money = (hour + 1) * 20;
        	}
        	System.out.print(sb.toString() + "  需繳費:" + money + "元");
        }else if (hour >= 4 && hour < 24){
        	if(hour%4 > 0 && minute == 0){
        		money = hour / 4 * 50 + hour%4 * 20;
        	}else if (hour%4 > 0 && minute > 0){
        		money = hour / 4 * 50 + (hour%4 + 1) * 20;
			}else{
        		money = hour / 4 * 50;
			}
        	System.out.print(sb.toString() + "  需繳費:" + money + "元");
        }else if (hour >= 24){
        	
        	if(hour%24 > 0 && hour%24%4 > 0 && minute > 0){
        		money = hour/24 * 150 + hour%24/4 * 50 + (hour%24/4 + 1) *20;
        	}else if (hour%24 > 0 && hour%24%4 > 0 && minute == 0){
        		money = hour/24 * 150 + hour%24/4 * 50 + (hour%24/4) *20;
        	}else if (hour%24 > 0 && hour%24%4 == 0 && minute > 0)
        		money = hour/24 * 150 + hour%24/4 * 50 + 20;
        	}else if (hour%24 > 0 && hour%24%4 == 0 && minute == 0){
        		money = hour/24 * 150 + hour%24/4 * 50 ;
        	}else{	
        		money = hour / 24 * 150;
        	System.out.print(sb.toString() + "  需繳費:" + money + "元");
        }
	}
}
