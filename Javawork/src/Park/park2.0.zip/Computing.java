package Park;

public class Computing {
	public static void main (String [] arge) {
		Parking parking = new Parking();
		parking.diffTime();
	}
}
