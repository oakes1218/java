package Grade;

public interface IStudent {
	/**
	* 姓名
	*/
	public String getName();
	public void setName(String name);
	/**
	* 分數
	*/
	public Integer getScore();
	public void setScore(Integer score);
	/**
	* 座號
	*/
	public Integer getId();
	public void setId(int id);

}
